import React from 'react';
import logo from '../../assets/logo2.png';

const Brand = () => {
    return (
        <div>
            <img className="w-52" src={logo} alt="logo" />
        </div>
    )
}

export default Brand
